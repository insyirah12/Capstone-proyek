export default class HomePage {
  async render() {
    return `
      <section class="hero-section text-center">
        <h1 class="hero-title display-4">Selamat Datang di Skivio</h1>
        <p class="hero-subtitle">Solusi deteksi dini kanker kulit berbasis AI yang membantu Anda memantau kesehatan kulit dengan mudah dan akurat</p>
        <a href="detection.html" class="btn btn-primary btn-lg">
          <i class="fas fa-search me-2"></i>Mulai Deteksi Sekarang
        </a>
      </section>

      <section class="section-container">
        <h2 class="section-title text-center">Jelajahi Fitur Skivio</h2>
        <p class="text-center mb-5">Temukan bagaimana Skivio dapat membantu Anda memantau kesehatan kulit melalui berbagai fitur unggulan kami</p>
        
        <div class="row g-4">
          <div class="col-md-6 col-lg-3">
            <div class="menu-card">
              <div class="card-body text-center">
                <div class="card-icon">
                  <i class="fas fa-home"></i>
                </div>
                <h3 class="h5">Home</h3>
                <p class="text-muted">Halaman utama yang memberikan gambaran lengkap tentang Skivio dan fitur-fiturnya. Temukan semua yang perlu Anda ketahui tentang layanan kami di satu tempat.</p>
                <a href="index.html" class="btn btn-outline-primary">Jelajahi</a>
              </div>
            </div>
          </div>
          
          <div class="col-md-6 col-lg-3">
            <div class="menu-card">
              <div class="card-body text-center">
                <div class="card-icon">
                  <i class="fas fa-info-circle"></i>
                </div>
                <h3 class="h5">Tentang</h3>
                <p class="text-muted">Pelajari lebih dalam tentang teknologi di balik Skivio, tim pengembang, dan bagaimana sistem kami bekerja untuk mendeteksi potensi masalah kulit.</p>
                <a href="about.html" class="btn btn-outline-primary">Pelajari</a>
              </div>
            </div>
          </div>
          
          <div class="col-md-6 col-lg-3">
            <div class="menu-card">
              <div class="card-body text-center">
                <div class="card-icon">
                  <i class="fas fa-search"></i>
                </div>
                <h3 class="h5">Deteksi Kulit</h3>
                <p class="text-muted">Fitur utama Skivio yang memungkinkan Anda mengunggah foto lesi kulit untuk dianalisis oleh AI kami. Dapatkan hasil instan dengan tingkat akurasi tinggi.</p>
                <a href="/detection" class="btn btn-outline-primary">Coba Sekarang</a>
              </div>
            </div>
          </div>
          
          <div class="col-md-6 col-lg-3">
            <div class="menu-card">
              <div class="card-body text-center">
                <div class="card-icon">
                  <i class="fas fa-sign-in-alt"></i>
                </div>
                <h3 class="h5">Masuk</h3>
                <p class="text-muted">Akses akun pribadi Anda untuk melihat riwayat deteksi, menyimpan hasil analisis, dan mendapatkan rekomendasi perawatan yang dipersonalisasi.</p>
                <a href="/login" class="btn btn-outline-primary">Masuk/Daftar</a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="section-container">
        <h2 class="section-title text-center">Bagaimana Skivio Bekerja?</h2>
        
          <div class="row">
            <div class="col-md-12 how-it-works-item" id="step1">
              <div class="how-it-works-content">
                <div class="how-it-works-header">
                  <div class="how-it-works-icon">
                    <i class="fas fa-camera"></i>
                  </div>
                  <h3 class="how-it-works-title">1. Unggah Gambar</h3>
                </div>
                <p class="how-it-works-text">Ambil foto lesi kulit menggunakan kamera smartphone atau unggah gambar yang sudah ada. Pastikan gambar jelas dan cukup terang untuk hasil analisis yang optimal.</p>
              </div>
              <img src="https://images.unsplash.com/photo-1581595219315-a187dd40c322?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" alt="Upload Image" class="how-it-works-image">
            </div>
            
            <div class="col-md-12 how-it-works-item" id="step2">
              <img src="https://images.unsplash.com/photo-1620712943543-bcc4688e7485?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" alt="AI Analysis" class="how-it-works-image">
              <div class="how-it-works-content">
                <div class="how-it-works-header">
                  <div class="how-it-works-icon">
                    <i class="fas fa-brain"></i>
                  </div>
                  <h3 class="how-it-works-title">2. Analisis AI</h3>
                </div>
                <p class="how-it-works-text">Teknologi pembelajaran mesin canggih kami akan menganalisis gambar Anda menggunakan model yang telah dilatih dengan ribuan gambar lesi kulit untuk memberikan hasil yang akurat.</p>
              </div>
            </div>
            
            <div class="col-md-12 how-it-works-item" id="step3">
              <div class="how-it-works-content">
                <div class="how-it-works-header">
                  <div class="how-it-works-icon">
                    <i class="fas fa-file-medical-alt"></i>
                  </div>
                  <h3 class="how-it-works-title">3. Hasil & Rekomendasi</h3>
                </div>
                <p class="how-it-works-text">Dapatkan laporan komprehensif tentang kondisi kulit Anda beserta rekomendasi tindakan berikutnya. Kami juga dapat menghubungkan Anda dengan dokter spesialis kulit jika diperlukan.</p>
              </div>
              <img src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" alt="Results" class="how-it-works-image">
            </div>
          </div>
        </section>

        <section class="modern-articles bg-light py-5" id="articles">
          <div class="container">
          <h2 class="section-title text-center" data-aos="fade-up">Artikel Terkini</h2>
          <p class="intro text-center mb-4" data-aos="fade-up" data-aos-delay="100">
          Dapatkan wawasan mendalam dan tips praktis seputar deteksi dini kanker kulit, perawatan lesi jinak, penggunaan sunscreen yang tepat, serta update penelitian dan teknologi AI terbaru.
          </p>

          <div id="artikelCarousel" class="carousel slide" data-bs-ride="carousel" data-aos="fade-up" data-aos-delay="200">
          <div class="carousel-indicators">
              <button type="button" data-bs-target="#artikelCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
              <button type="button" data-bs-target="#artikelCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
          </div>
          <div class="carousel-inner">
              <!-- Slide 1 -->
              <div class="carousel-item active">
              <div class="row gx-4">
                  <!-- Artikel 1 -->
                  <div class="col-md-4">
                    <div class="article-card">
                        <img src="https://images.unsplash.com/photo-1584270354949-7d79f8da58f7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" class="w-100" alt="Melanoma AI">
                        <div class="article-content">
                        <h5>Deteksi Melanoma dengan AI Modern</h5>
                        <p>Melanoma adalah bentuk kanker kulit yang paling agresif. Dalam artikel ini, kita membahas bagaimana CNN dapat mempelajari ciri lesi gelap pada kulit untuk pra-diagnosis dengan akurasi hingga 95%.</p>
                        <a href="artikel-melanoma.html" class="read-more">Baca Selengkapnya</a>
                        </div>
                    </div>
                  </div>
                  <!-- Artikel 2 -->
                  <div class="col-md-4">
                  <div class="article-card">
                      <img src="https://images.unsplash.com/photo-1592496001025-0da447507d3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" class="w-100" alt="Lesi Jinak">
                      <div class="article-content">
                      <h5>Perawatan Lesi Jinak di Rumah</h5>
                      <p>Pelajari cara membersihkan, memilih salep antiseptik, memantau perubahan, dan kapan sebaiknya konsultasi ke dokter spesialis kulit.</p>
                      <a href="artikel-lesi-jinak.html" class="read-more">Baca Selengkapnya</a>
                      </div>
                  </div>
                  </div>
                  <!-- Artikel 3 -->
                  <div class="col-md-4">
                  <div class="article-card">
                      <img src="https://images.unsplash.com/photo-1582719478177-0fa586c747b3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" class="w-100" alt="Sunscreen">
                      <div class="article-content">
                      <h5>Sunscreen: Perisai Terbaik Kulit Anda</h5>
                      <p>Bedakan SPF & PA, pilih mineral vs kimia, cara aplikasi benar, dan kapan re-apply agar selalu terlindungi.</p>
                      <a href="artikel-sunscreen.html" class="read-more">Baca Selengkapnya</a>
                      </div>
                  </div>
                  </div>
              </div>
              </div>

              <!-- Slide 2 -->
              <div class="carousel-item">
              <div class="row gx-4">
                  <!-- Artikel 4 -->
                  <div class="col-md-4">
                  <div class="article-card">
                      <img src="https://images.unsplash.com/photo-1597262975002-c5c3b14bbd62?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" class="w-100" alt="Gejala Awal">
                      <div class="article-content">
                      <h5>Mengenali Gejala Awal Kanker Kulit</h5>
                      <p>Kenali tanda-tanda mulai munculnya kanker kulit: perubahan warna, bentuk, dan tekstur lesi yang harus segera diwaspadai.</p>
                      <a href="artikel-gejala-awal.html" class="read-more">Baca Selengkapnya</a>
                      </div>
                  </div>
                  </div>
                  <!-- Artikel 5 -->
                  <div class="col-md-4">
                  <div class="article-card">
                      <img src="https://images.unsplash.com/photo-1576765607921-31d6b5d3b53e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" class="w-100" alt="Teledermatologi">
                      <div class="article-content">
                      <h5>Teledermatologi: Konsultasi Jarak Jauh</h5>
                      <p>Bagaimana layanan teledermatologi membantu diagnosis cepat tanpa antre, dengan dokter memeriksa gambar lesi Anda dari jarak jauh.</p>
                      <a href="artikel-teledermatologi.html" class="read-more">Baca Selengkapnya</a>
                      </div>
                  </div>
                  </div>
                  <!-- Artikel 6 -->
                  <div class="col-md-4">
                  <div class="article-card">
                      <img src="https://images.unsplash.com/photo-1594737625785-317adf40e858?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" class="w-100" alt="Diet dan Kulit">
                      <div class="article-content">
                      <h5>Diet Sehat untuk Pencegahan</h5>
                      <p>Peran nutrisi—antioksidan, vitamin, dan asam lemak—dalam menjaga kesehatan kulit dan menurunkan risiko kanker.</p>
                      <a href="artikel-diet-kulit.html" class="read-more">Baca Selengkapnya</a>
                      </div>
                  </div>
                  </div>
              </div>
              </div>
          </div>

          <!-- Controls -->
          <button class="carousel-control-prev" type="button" data-bs-target="#artikelCarousel" data-bs-slide="prev">
              <span class="carousel-control-prev-icon"></span>
              <span class="visually-hidden">Sebelumnya</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#artikelCarousel" data-bs-slide="next">
              <span class="carousel-control-next-icon"></span>
              <span class="visually-hidden">Berikutnya</span>
          </button>
          </div>
      </div>
      </section>

      <section class="section-container text-center">
        <h2 class="section-title">Apa Kata Pengguna?</h2>
        
        <div class="row g-4">
          <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100">
              <div class="card-body">
                <img src="https://randomuser.me/api/portraits/women/32.jpg" alt="User" class="rounded-circle mb-3" width="80">
                <h5 class="card-title">Sarah Wijaya</h5>
                <p class="text-muted">"Skivio membantu saya mendeteksi tahi lalat yang mencurigakan lebih awal. Hasilnya akurat dan sesuai dengan diagnosis dokter!"</p>
                <div class="text-warning">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                </div>
              </div>
            </div>
          </div>
          
          <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100">
              <div class="card-body">
                <img src="https://randomuser.me/api/portraits/men/45.jpg" alt="User" class="rounded-circle mb-3" width="80">
                <h5 class="card-title">Budi Santoso</h5>
                <p class="text-muted">"Sangat mudah digunakan. Dalam hitungan detik saya bisa tahu apakah lesi kulit saya perlu diperiksakan ke dokter atau tidak."</p>
                <div class="text-warning">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
                </div>
              </div>
            </div>
          </div>
          
          <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100">
              <div class="card-body">
                <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="User" class="rounded-circle mb-3" width="80">
                <h5 class="card-title">Dewi Anggraeni</h5>
                <p class="text-muted">"Sebagai seseorang dengan banyak tahi lalat, Skivio sangat membantu memantau perubahan yang terjadi pada kulit saya."</p>
                <div class="text-warning">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    `;
  }

  async afterRender() {
    // Initialize animations or event listeners
    this.initHowItWorksAnimation();
    this.initAOS();
  }

  initHowItWorksAnimation() {
    const steps = document.querySelectorAll('.how-it-works-item');
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animated');
          const index = Array.from(steps).indexOf(entry.target);
          entry.target.style.transitionDelay = `${index * 0.2}s`;
        }
      });
    }, { threshold: 0.1 });
    
    steps.forEach(step => {
      observer.observe(step);
    });
  }

  initAOS() {
    if (typeof AOS !== 'undefined') {
      AOS.init({
        duration: 800,
        once: true
      });
    }
  }

  cleanup() {
    // Clean up any event listeners
    const steps = document.querySelectorAll('.how-it-works-item');
    steps.forEach(step => {
      step.classList.remove('animated');
      step.style.transitionDelay = '';
    });
  }
}

