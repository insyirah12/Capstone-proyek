class LoginPage {
  constructor() {
    this.isLoginPage = true;
  }

  async render() {
    return `
      <div class="card login-card">
        <div class="card-body">
          <!-- Logo -->
          <img src="images/logo_skivio.png" alt="Skivio Logo" class="login-logo">
          
          <!-- Title -->
          <div class="login-title">Sign In to Skivio</div>

          <!-- Form -->
          <form novalidate id="loginForm">
            <div class="mb-3">
              <label for="email" class="form-label">Email address</label>
              <input type="email" class="form-control" id="email" placeholder="you@example.com" required>
              <div class="invalid-feedback">Please enter a valid email address</div>
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input type="password" class="form-control" id="password" placeholder="••••••••" required>
              <div class="invalid-feedback">Please enter your password</div>
            </div>
            <div class="d-flex justify-content-between align-items-center mb-4">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="rememberMe">
                <label class="form-check-label" for="rememberMe">Remember me</label>
              </div>
              <a href="#/forgot-password" class="forgot-link">Forgot Password?</a>
            </div>
            <button type="submit" class="btn btn-primary w-100" id="loginBtn">
              <span id="loginBtnText">Sign In</span>
              <span id="loginSpinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
            </button>
          </form>

          <!-- Sign Up -->
          <p class="text-center mt-4 signup-link">
            Don't have an account? <a href="#/register">Sign Up</a>
          </p>
        </div>
      </div>
    `;
  }

  async afterRender() {
    // Initialize form elements
    this.loginForm = document.getElementById('loginForm');
    this.emailInput = document.getElementById('email');
    this.passwordInput = document.getElementById('password');
    this.loginBtn = document.getElementById('loginBtn');
    this.loginBtnText = document.getElementById('loginBtnText');
    this.loginSpinner = document.getElementById('loginSpinner');

    // Form validation
    this.loginForm.addEventListener('submit', (e) => this._handleLogin(e));

    // Focus on email input when page loads
    this.emailInput.focus();
  }

  async _handleLogin(e) {
    e.preventDefault();
    
    // Validate form
    if (!this.loginForm.checkValidity()) {
      e.stopPropagation();
      this.loginForm.classList.add('was-validated');
      return;
    }

    // Show loading state
    this.loginBtn.disabled = true;
    this.loginBtnText.textContent = 'Signing in...';
    this.loginSpinner.classList.remove('d-none');

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // In a real app, you would call your authentication API here
      // const response = await authApi.login(email, password);
      
      // For demo purposes, we'll just check for specific credentials
      const email = this.emailInput.value;
      const password = this.passwordInput.value;
      
      if (email === 'demo@skivio.com' && password === 'demo123') {
            localStorage.setItem('user', JSON.stringify({
                email: email,
                name: 'Demo User',
                avatar: 'images/user.jpg' // Placeholder avatar
            }));
            
            // Force a full page reload to update auth state everywhere
            window.location.href = '#/';
            window.location.reload();
      } else {
        // Show error message
        this._showError('Invalid email or password. Please try again.');
      }
    } catch (error) {
      console.error('Login error:', error);
      this._showError('An error occurred during login. Please try again.');
    } finally {
      // Reset button state
      this.loginBtn.disabled = false;
      this.loginBtnText.textContent = 'Sign In';
      this.loginSpinner.classList.add('d-none');
    }
  }

  _showError(message) {
    // Remove any existing alerts
    const existingAlert = document.querySelector('.alert');
    if (existingAlert) existingAlert.remove();
    
    // Create and show error alert
    const alert = document.createElement('div');
    alert.className = 'alert alert-danger mt-3';
    alert.innerHTML = `
      <i class="fas fa-exclamation-circle me-2"></i>
      ${message}
    `;
    
    this.loginForm.parentNode.insertBefore(alert, this.loginForm.nextSibling);
    
    // Focus on password field
    this.passwordInput.focus();
  }

  cleanup() {
    // Clean up event listeners if needed
    if (this.loginForm) {
      this.loginForm.removeEventListener('submit', this._handleLogin);
    }
  }
}

export default LoginPage;