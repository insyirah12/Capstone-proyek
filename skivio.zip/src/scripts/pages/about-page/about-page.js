// about-page.js

export default class AboutPage {
  constructor() {
    // Store references to event handlers so we can remove them later
    this.teamMemberEnterHandler = (member) => this.handleTeamMemberEnter(member);
    this.teamMemberLeaveHandler = (member) => this.handleTeamMemberLeave(member);
    this.smoothScrollHandler = (e) => this.handleSmoothScroll(e);
  }
  
  async render() {
    return `
      <!-- Hero Section -->
      <section class="about-hero">
        <div class="hero-overlay">
          <div class="hero-content">
            <h1 class="hero-title">Deteksi Dini Kanker Kulit</h1>
            <p class="hero-subtitle">Dengan teknologi AI terbaru untuk membantu identifikasi potensi masalah kulit sejak dini</p>
            <div class="hero-buttons">
              <a href="#/detection" class="btn btn-primary">
                <i class="fas fa-search me-2"></i>Coba Sekarang
              </a>
              <a href="#features" class="btn btn-outline">
                <i class="fas fa-info-circle me-2"></i>Pelajari Lebih Lanjut
              </a>
            </div>
          </div>
        </div>
        <div class="hero-waves">
          <svg viewBox="0 0 1200 120" preserveAspectRatio="none">
            <path d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" opacity=".25" fill="#fff"></path>
            <path d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z" opacity=".5" fill="#fff"></path>
            <path d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z" fill="#fff"></path>
          </svg>
        </div>
      </section>

      <!-- Features Section -->
      <section id="features" class="about-section">
        <div class="about-container">
          <div class="text-center mb-5">
            <h2 class="section-title">Kenapa Memilih Skivio?</h2>
            <p class="text-muted">Platform deteksi kanker kulit berbasis AI yang cepat, akurat, dan mudah digunakan</p>
          </div>

          <div class="row g-4 justify-content-center">
            <div class="col-md-4" data-aos="fade-up">
              <div class="card card-feature h-100">
                <div class="card-body-about text-center p-4">
                  <div class="feature-icon">
                    <i class="fas fa-bolt"></i>
                  </div>
                  <h3 class="h5">Cepat dan Akurat</h3>
                  <p class="text-muted">Hasil deteksi dalam hitungan detik dengan akurasi tinggi menggunakan model AI terbaru.</p>
                </div>
              </div>
            </div>
            
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
              <div class="card card-feature h-100">
                <div class="card-body-about text-center p-4">
                  <div class="feature-icon">
                    <i class="fas fa-shield-alt"></i>
                  </div>
                  <h3 class="h5">Privasi Terjaga</h3>
                  <p class="text-muted">Data Anda aman dan tidak disimpan tanpa izin. Kami mengutamakan keamanan informasi Anda.</p>
                </div>
              </div>
            </div>

            <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
              <div class="card card-feature h-100">
                <div class="card-body-about text-center p-4">
                  <div class="feature-icon">
                    <i class="fas fa-mobile-alt"></i>
                  </div>
                  <h3 class="h5">Mudah Digunakan</h3>
                  <p class="text-muted">Antarmuka yang sederhana dan intuitif untuk pengalaman pengguna yang optimal.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- About Us Section -->
      <section class="about-section" style="background: white;">
        <div class="about-container">
          <div class="about-content">
            <div class="about-text" data-aos="fade-right">
              <h2 class="section-title">Tentang Skivio</h2>
              <p class="mb-4">Skivio adalah platform deteksi dini kanker kulit yang memanfaatkan teknologi pembelajaran mesin modern untuk membantu identifikasi potensi masalah kulit sejak dini.</p>
              <p class="mb-4">Dikembangkan oleh tim ahli dengan pengalaman bertahun-tahun di bidang kesehatan dan teknologi, Skivio hadir untuk memberikan solusi yang mudah diakses oleh semua orang.</p>
              <div class="d-flex align-items-center">
                <i class="fas fa-check-circle text-success me-2"></i>
                <span>Deteksi melalui gambar atau kamera</span>
              </div>
              <div class="d-flex align-items-center my-2">
                <i class="fas fa-check-circle text-success me-2"></i>
                <span>Analisis karakteristik lesi kulit</span>
              </div>
              <div class="d-flex align-items-center">
                <i class="fas fa-check-circle text-success me-2"></i>
                <span>Rekomendasi tindakan lanjutan</span>
              </div>
            </div>
            <div class="about-image" data-aos="fade-left">
              <div class="image-container">
                <img src="https://images.unsplash.com/photo-1579684453423-f84349ef60b0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Skin Analysis" class="main-image">
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Technology Section -->
      <section class="about-section">
        <div class="about-container">
          <div class="text-center mb-5">
            <h2 class="section-title">Teknologi Kami</h2>
            <p class="text-muted">Memanfaatkan teknologi terkini untuk deteksi yang lebih akurat</p>
          </div>

          <div class="row g-4">
            <div class="col-md-4" data-aos="zoom-in">
              <div class="card card-feature h-100">
                <div class="card-body-about text-center p-4">
                  <div class="feature-icon">
                    <i class="fas fa-brain"></i>
                  </div>
                  <h3 class="h5">Deep Learning</h3>
                  <p class="text-muted">Menggunakan jaringan saraf tiruan untuk mengenali pola lesi kulit dengan akurasi tinggi.</p>
                </div>
              </div>
            </div>
            
            <div class="col-md-4" data-aos="zoom-in" data-aos-delay="100">
              <div class="card card-feature h-100">
                <div class="card-body-about text-center p-4">
                  <div class="feature-icon">
                    <i class="fas fa-chart-line"></i>
                  </div>
                  <h3 class="h5">Analisis ABCD</h3>
                  <p class="text-muted">Metode standar dermatologi untuk mengevaluasi karakteristik lesi kulit.</p>
                </div>
              </div>
            </div>
            
            <div class="col-md-4" data-aos="zoom-in" data-aos-delay="200">
              <div class="card card-feature h-100">
                <div class="card-body-about text-center p-4">
                  <div class="feature-icon">
                    <i class="fas fa-cloud"></i>
                  </div>
                  <h3 class="h5">Cloud Computing</h3>
                  <p class="text-muted">Proses analisis dilakukan di server cloud untuk kecepatan dan keandalan.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Team Section -->
      <section class="about-section" style="background: white;">
        <div class="about-container">
          <div class="text-center mb-5">
            <h2 class="section-title">Tim Pengembang</h2>
            <p class="text-muted">Tim profesional yang berdedikasi untuk kesehatan kulit Anda</p>
          </div>

          <div class="row">
            <div class="col-md-4" data-aos="fade-up">
              <div class="team-member">
                <div class="team-member-img">
                  <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80" alt="Team Member" class="img-fluid">
                  <div class="social-links">
                    <a href="#"><i class="fab fa-linkedin"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                  </div>
                </div>
                <h4 class="h5 mt-3">Fakhry Muzhaffar Arif</h4>
                <p class="text-muted">Front-End Developer</p>
              </div>
            </div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
              <div class="team-member">
                <div class="team-member-img">
                  <img src="images/jumriana.jpg" alt="Team Member" class="img-fluid">ko
                  <div class="social-links">
                    <a href="#"><i class="fab fa-linkedin"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                  </div>
                </div>
                <h4 class="h5 mt-3">Jumriana</h4>
                <p class="text-muted">UI/UX Designer</p>
              </div>
            </div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
              <div class="team-member">
                <div class="team-member-img">
                  <img src="images/fakhry.jpg" alt="Team Member" class="img-fluid">
                  <div class="social-links">
                    <a href="https://www.linkedin.com/in/fakhry-muzhaffar-arif-28b5572b5/"><i class="fab fa-linkedin"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                  </div>
                </div>
                <h4 class="h5 mt-3">Fakhry Muzhaffar Arif</h4>
                <p class="text-muted">Project Manager</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- CTA Section -->
      <section class="about-section" style="background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%); color: white; margin-top:50px;">
        <div class="about-container text-center">
          <h2 class="section-title" style="color: white;">Siap Memulai Deteksi?</h2>
          <p class="mb-4" style="opacity: 0.9;">Mulai deteksi sekarang dan dapatkan analisis instan tentang kondisi kulit Anda</p>
          <a href="#/detection" class="btn btn-primary btn-lg">
            <i class="fas fa-search me-2"></i>Mulai Deteksi
          </a>
        </div>
      </section>
    `;
  }

  async afterRender() {
    // Initialize animations
    this.initAOS();
    this.initTeamHover();
    this.initSmoothScrolling();
  }

  initAOS() {
    if (typeof AOS !== 'undefined') {
      AOS.init({
        duration: 800,
        once: true,
        easing: 'ease-in-out',
        offset: 100
      });
    }
  }

  initTeamHover() {
    const teamMembers = document.querySelectorAll('.team-member');
    teamMembers.forEach(member => {
      member.addEventListener('mouseenter', () => this.handleTeamMemberEnter(member));
      member.addEventListener('mouseleave', () => this.handleTeamMemberLeave(member));
    });
  }

  handleTeamMemberEnter(member) {
    member.querySelector('.social-links').style.opacity = '1';
    member.querySelector('.social-links').style.transform = 'translateY(0)';
  }

  handleTeamMemberLeave(member) {
    member.querySelector('.social-links').style.opacity = '0';
    member.querySelector('.social-links').style.transform = 'translateY(20px)';
  }

  initSmoothScrolling() {
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', this.smoothScrollHandler);
    });
  }

  handleSmoothScroll(e) {
    // Skip if it's a route link (starts with #/)
    if (e.currentTarget.getAttribute('href').startsWith('#/')) {
      return;
    }
    
    e.preventDefault();
    
    const targetId = e.currentTarget.getAttribute('href');
    if (targetId === '#') return;
    
    try {
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        targetElement.scrollIntoView({
          behavior: 'smooth'
        });
      }
    } catch (error) {
      console.error('Smooth scrolling error:', error);
    }
  }

  initSmoothScrolling() {
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function(e) {
        // Skip if it's a route link (starts with #/)
        if (this.getAttribute('href').startsWith('#/')) {
          return;
        }
        
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        
        try {
          const targetElement = document.querySelector(targetId);
          if (targetElement) {
            targetElement.scrollIntoView({
              behavior: 'smooth'
            });
          }
        } catch (error) {
          console.error('Smooth scrolling error:', error);
        }
      });
    });
  }

  cleanup() {
    // Clean up event listeners properly
    const teamMembers = document.querySelectorAll('.team-member');
    teamMembers.forEach(member => {
      member.removeEventListener('mouseenter', this.teamMemberEnterHandler);
      member.removeEventListener('mouseleave', this.teamMemberLeaveHandler);
    });

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.removeEventListener('click', this.smoothScrollHandler);
    });
  }
}