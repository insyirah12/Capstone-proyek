// detection-page.js
import { db } from '../../utils/db.js';

class DetectionPage {
  #cameraStream = null;
  #model = null;

  constructor(isProtected = false) {
    this.isProtected = isProtected;
  }

  async render() {
    return `
      <!-- Detection Section -->
      <section class="section-detection">
        <h2 class="section-title text-center">Deteksi Kanker Kulit</h2>
        <p class="text-center mb-5">Unggah foto lesi kulit atau gunakan kamera untuk mendapatkan analisis instan dari model AI kami</p>
        
        <div class="detection-container">
          <!-- Camera Preview -->
          <div class="camera-container">
            <video id="camera-preview" autoplay playsinline style="background: #eee;"></video>
            <div class="camera-permission-prompt" id="camera-permission-prompt">
              <button class="btn btn-primary" id="enable-camera-btn">
                <i class="fas fa-camera me-2"></i>Aktifkan Kamera
              </button>
            </div>
            <div class="camera-controls" style="display: none;" id="camera-controls">
              <div class="capture-btn" id="capture-btn">
                <i class="fas fa-camera"></i>
              </div>
            </div>
          </div>
          
          <!-- Or Divider -->
          <div class="text-muted">ATAU</div>
          
          <!-- Upload Area -->
          <div class="upload-area" id="upload-area">
            <div class="upload-icon">
              <i class="fas fa-cloud-upload-alt"></i>
            </div>
            <h4>Seret & Lepaskan Gambar di Sini</h4>
            <p class="text-muted">Format yang didukung: JPG, PNG (Maks. 5MB)</p>
            <button class="btn btn-primary mt-2" id="select-file-btn">Pilih File</button>
            <input type="file" id="file-input" accept="image/*" style="display: none;">
          </div>
          
          <!-- Loading State -->
          <div class="loading-container" id="loading-container">
            <div class="spinner"></div>
            <h4>Menganalisis Gambar...</h4>
            <p class="text-muted">Model AI kami sedang memproses gambar Anda</p>
          </div>
          
          <!-- Results Container -->
          <div class="results-container" id="results-container">
            <h3 class="section-title">Hasil Analisis</h3>
            
            <div class="result-card">
              <img src="" alt="Analyzed Skin" class="result-image" id="result-image">
              <div class="result-details">
                <h3 class="result-title" id="result-title">Hasil Deteksi</h3>
                <div class="result-probability" id="result-probability">85%</div>
                <p class="result-description" id="result-description">
                  Berdasarkan analisis kami, lesi kulit ini menunjukkan karakteristik yang perlu diperhatikan.
                </p>
                
                <div class="result-features">
                  <h5>Karakteristik Lesi:</h5>
                  <div class="feature-item">
                    <span class="feature-name">Asimetri</span>
                    <span class="feature-value" id="asymmetry-value">Tinggi</span>
                  </div>
                  <div class="feature-item">
                    <span class="feature-name">Batas</span>
                    <span class="feature-value" id="border-value">Tidak Rata</span>
                  </div>
                  <div class="feature-item">
                    <span class="feature-name">Warna</span>
                    <span class="feature-value" id="color-value">Beragam</span>
                  </div>
                  <div class="feature-item">
                    <span class="feature-name">Diameter</span>
                    <span class="feature-value" id="diameter-value">>6mm</span>
                  </div>
                  <div class="feature-item">
                    <span class="feature-name">Evolusi</span>
                    <span class="feature-value" id="evolution-value">Perubahan</span>
                  </div>
                </div>
                
                <div class="recommendation">
                  <h5>Rekomendasi:</h5>
                  <p id="recommendation-text">
                    Kami merekomendasikan untuk berkonsultasi dengan dokter spesialis kulit dalam waktu dekat untuk pemeriksaan lebih lanjut. 
                    Hasil ini tidak menggantikan diagnosis medis profesional.
                  </p>
                </div>
                
                <button class="btn btn-primary mt-3" id="new-analysis-btn">
                  <i class="fas fa-redo me-2"></i>Analisis Baru
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <!-- Information Section -->
      <section class="section-detection">
        <h2 class="section-title">Panduan Pengambilan Gambar</h2>
        <div class="row">
          <div class="col-md-6">
            <div class="mb-4">
              <h5><i class="fas fa-check-circle text-success me-2"></i> Yang Harus Dilakukan:</h5>
              <ul>
                <li>Pastikan area yang difoto cukup terang</li>
                <li>Jaga jarak sekitar 15-20 cm dari lesi</li>
                <li>Gunakan latar belakang polos yang kontras</li>
                <li>Fokuskan kamera pada lesi kulit</li>
              </ul>
            </div>
          </div>
          <div class="col-md-6">
            <div class="mb-4">
              <h5><i class="fas fa-times-circle text-danger me-2"></i> Yang Harus Dihindari:</h5>
              <ul>
                <li>Jangan menggunakan flash langsung</li>
                <li>Hindari bayangan pada area lesi</li>
                <li>Jangan mengunggah gambar buram</li>
                <li>Hindari area kulit yang terluka atau berdarah</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    `;
  }

  async afterRender() {
    // Initialize elements
    this.cameraPermissionPrompt = document.getElementById('camera-permission-prompt');
    this.enableCameraBtn = document.getElementById('enable-camera-btn');
    this.cameraPreview = document.getElementById('camera-preview');
    this.cameraControls = document.getElementById('camera-controls');
    this.captureBtn = document.getElementById('capture-btn');
    this.uploadArea = document.getElementById('upload-area');
    this.fileInput = document.getElementById('file-input');
    this.selectFileBtn = document.getElementById('select-file-btn');
    this.loadingContainer = document.getElementById('loading-container');
    this.resultsContainer = document.getElementById('results-container');
    this.resultImage = document.getElementById('result-image');
    this.resultTitle = document.getElementById('result-title');
    this.resultProbability = document.getElementById('result-probability');
    this.resultDescription = document.getElementById('result-description');
    this.recommendationText = document.getElementById('recommendation-text');
    this.newAnalysisBtn = document.getElementById('new-analysis-btn');
    
    // Feature elements
    this.asymmetryValue = document.getElementById('asymmetry-value');
    this.borderValue = document.getElementById('border-value');
    this.colorValue = document.getElementById('color-value');
    this.diameterValue = document.getElementById('diameter-value');
    this.evolutionValue = document.getElementById('evolution-value');

    // Setup event listeners
    this._setupCameraPermission();
    this._setupUpload();
    this._setupButtons();
    
    // Load model
    await this._loadModel();

    // Focus main content for accessibility
    const mainContent = document.querySelector('main');
    if (mainContent) {
      mainContent.setAttribute('tabindex', '-1');
      mainContent.focus();
    }
  }

  async _loadModel() {
    try {
      // Show loading state
      this.loadingContainer.style.display = 'block';
      
      // In a real implementation, you would load your TensorFlow.js model here
      // Example:
      // this.#model = await tf.loadLayersModel('path/to/model.json');
      
      // For demo purposes, we'll simulate model loading
      await new Promise(resolve => setTimeout(resolve, 1500));
      console.log('Model loaded (simulated)');
    } catch (error) {
      console.error('Error loading model:', error);
      alert('Gagal memuat model AI. Silakan refresh halaman.');
    } finally {
      this.loadingContainer.style.display = 'none';
    }
  }

  _setupButtons() {
    this.newAnalysisBtn.addEventListener('click', () => this._resetAnalysis());
  }

  _setupCameraPermission() {
    this.enableCameraBtn.addEventListener('click', async () => {
      try {
        await this._initCamera();
        this.cameraPermissionPrompt.style.display = 'none';
        this.cameraControls.style.display = 'flex';
      } catch (error) {
        console.error('Camera access denied:', error);
        alert('Akses kamera ditolak. Silakan berikan izin untuk menggunakan fitur kamera.');
      }
    });
  }

  async _initCamera() {
    try {
      this.#cameraStream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        } 
      });
      this.cameraPreview.srcObject = this.#cameraStream;
      
      // Setup capture button
      this.captureBtn.addEventListener('click', () => this._capturePhoto());
    } catch (err) {
      console.error('Error accessing camera:', err);
      throw err;
    }
  }

  _setupUpload() {
    this.selectFileBtn.addEventListener('click', () => this.fileInput.click());

    this.fileInput.addEventListener('change', (e) => {
      if (e.target.files.length > 0) {
        this._processImage(e.target.files[0]);
      }
    });

    this.uploadArea.addEventListener('dragover', (e) => {
      e.preventDefault();
      this.uploadArea.style.borderColor = 'var(--primary-color)';
      this.uploadArea.style.backgroundColor = 'rgba(207, 225, 255, 0.3)';
    });

    this.uploadArea.addEventListener('dragleave', (e) => {
      e.preventDefault();
      this.uploadArea.style.borderColor = '#ccc';
      this.uploadArea.style.backgroundColor = 'transparent';
    });

    this.uploadArea.addEventListener('drop', (e) => {
      e.preventDefault();
      this.uploadArea.style.borderColor = '#ccc';
      this.uploadArea.style.backgroundColor = 'transparent';
      
      if (e.dataTransfer.files.length > 0) {
        this._processImage(e.dataTransfer.files[0]);
      }
    });
  }

  async _capturePhoto() {
    // Create canvas to capture image
    const canvas = document.createElement('canvas');
    canvas.width = this.cameraPreview.videoWidth;
    canvas.height = this.cameraPreview.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(this.cameraPreview, 0, 0, canvas.width, canvas.height);
    
    // Convert to blob and process
    canvas.toBlob((blob) => {
      this._processImage(blob);
    }, 'image/jpeg', 0.9);
  }

  async _processImage(imageBlob) {
    // Show loading state
    this.loadingContainer.style.display = 'block';
    this.cameraPreview.style.display = 'none';
    this.cameraControls.style.display = 'none';
    this.uploadArea.style.display = 'none';
    this.cameraPermissionPrompt.style.display = 'none';
    
    // Create object URL for the image
    const imageUrl = URL.createObjectURL(imageBlob);
    this.resultImage.src = imageUrl;
    
    // Simulate ML processing delay
    setTimeout(async () => {
      await this._simulateModelPrediction();
      
      // Hide loading, show results
      this.loadingContainer.style.display = 'none';
      this.resultsContainer.style.display = 'block';
    }, 3000);
  }

  async _simulateModelPrediction() {
    // Random results for demo
    const isMalignant = Math.random() > 0.5;
    const probability = (Math.random() * 30 + (isMalignant ? 50 : 20)).toFixed(1);
    
    // Set results
    if (isMalignant) {
      this.resultTitle.textContent = 'Potensi Kanker Kulit Terdeteksi';
      this.resultProbability.textContent = `${probability}%`;
      this.resultProbability.className = 'result-probability result-malignant';
      this.resultDescription.textContent = 'Lesi kulit ini menunjukkan beberapa karakteristik yang mengkhawatirkan dan memerlukan evaluasi lebih lanjut oleh profesional medis.';
      this.recommendationText.textContent = 'Kami sangat merekomendasikan untuk berkonsultasi dengan dokter spesialis kulit dalam waktu 1-2 minggu. Deteksi dini sangat penting untuk penanganan yang efektif.';
    } else {
      this.resultTitle.textContent = 'Lesi Jinak Terdeteksi';
      this.resultProbability.textContent = `${probability}%`;
      this.resultProbability.className = 'result-probability result-benign';
      this.resultDescription.textContent = 'Lesi kulit ini tampak jinak berdasarkan karakteristik yang terdeteksi, namun pemantauan rutin tetap disarankan.';
      this.recommendationText.textContent = 'Meskipun lesi ini tampak jinak, kami sarankan untuk memantau perubahan secara berkala. Jika ada perubahan bentuk, warna, atau ukuran, silakan periksakan kembali.';
    }

    
    
    // Set random features (ABCDE rule for melanoma)
    const features = {
      asymmetry: ['Tinggi', 'Sedang', 'Rendah'][Math.floor(Math.random() * 3)],
      border: ['Tidak Rata', 'Agak Rata', 'Rata'][Math.floor(Math.random() * 3)],
      color: ['Beragam', '2-3 Warna', 'Satu Warna'][Math.floor(Math.random() * 3)],
      diameter: ['>6mm', '≈6mm', '<6mm'][Math.floor(Math.random() * 3)],
      evolution: ['Perubahan', 'Stabil'][Math.floor(Math.random() * 2)]
    };
    
    this.asymmetryValue.textContent = features.asymmetry;
    this.borderValue.textContent = features.border;
    this.colorValue.textContent = features.color;
    this.diameterValue.textContent = features.diameter;
    this.evolutionValue.textContent = features.evolution;
  
    const user = JSON.parse(localStorage.getItem('user'));
    const historyItem = {
      date: new Date().toLocaleString(),
      image: this.resultImage.src,
      isMalignant,
      probability,
      features,
      recommendation: this.recommendationText.textContent,
      userId: user.email // Store user reference
    };

    await db.addHistory(historyItem);
  }

  _resetAnalysis() {
    this.resultsContainer.style.display = 'none';
    if (this.#cameraStream) {
      this.cameraPreview.style.display = 'block';
      this.cameraControls.style.display = 'flex';
      this.cameraPermissionPrompt.style.display = 'none';
    } else {
      this.cameraPreview.style.display = 'block';
      this.cameraPermissionPrompt.style.display = 'flex';
      this.cameraControls.style.display = 'none';
    }
    this.uploadArea.style.display = 'block';
  }

  cleanup() {
    if (this.#cameraStream) {
      this.#cameraStream.getTracks().forEach(track => track.stop());
      this.#cameraStream = null;
    }
  }
}

export default DetectionPage;