import { db } from '../../utils/db';

class HistoryPage {
  constructor() {
    this.isProtected = true;
    this.historyData = [];
    this.viewDetailHandlers = [];
    this.modal = null;
  }

  async render() {
    const user = JSON.parse(localStorage.getItem('user'));
    
    if (!user) {
      return `
        <section class="section-detection">
          <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle me-2"></i>
            Anda harus login untuk mengakses riwayat analisis.
          </div>
          <div class="text-center mt-3">
            <a href="#/login" class="btn btn-primary">Login</a>
          </div>
        </section>
      `;
    }

    try {
      // Show loading state
      const loadingHTML = `
        <div class="text-center py-5">
          <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
          <p class="mt-3">Memuat riwayat...</p>
        </div>
      `;
      
      // Render loading state immediately
      const tempContainer = document.createElement('div');
      tempContainer.innerHTML = loadingHTML;
      
      // Fetch from IndexedDB
      this.historyData = await db.getAllHistory();
      
      // Return the actual content
      return this.getHistoryHTML();
    } catch (error) {
      console.error('Error loading history:', error);
      return `
        <section class="section-detection">
          <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle me-2"></i>
            Gagal memuat riwayat analisis.
          </div>
          <div class="text-center mt-3">
            <button class="btn btn-primary" onclick="window.location.reload()">
              <i class="fas fa-sync-alt me-2"></i>Coba Lagi
            </button>
          </div>
        </section>
      `;
    }
  }

  getHistoryHTML() {
    return `
      <!-- History Section -->
      <section class="section-detection">
        <h2 class="section-title">Riwayat Analisis</h2>
        <p class="mb-4">Berikut adalah riwayat deteksi kulit yang telah Anda lakukan.</p>
        
        ${this.historyData.length === 0 ? `
          <div class="text-center py-5">
            <i class="fas fa-history fa-3x text-muted mb-3"></i>
            <h4>Belum ada riwayat analisis</h4>
            <p class="text-muted">Setelah melakukan analisis, riwayat akan muncul di sini</p>
            <a href="#/detection" class="btn btn-primary mt-3">
              <i class="fas fa-search me-2"></i>Lakukan Analisis
            </a>
          </div>
        ` : `
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>Tanggal</th>
                  <th>Gambar</th>
                  <th>Hasil</th>
                  <th>Probabilitas</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                ${this.historyData.map((item, index) => `
                  <tr>
                    <td>${item.date}</td>
                    <td>
                      <img src="${item.image}" alt="Analisis kulit" class="img-thumbnail" style="width: 80px; height: 60px; object-fit: cover;">
                    </td>
                    <td>
                      <span class="badge ${item.isMalignant ? 'bg-danger' : 'bg-success'}">
                        ${item.isMalignant ? 'Potensi Kanker' : 'Jinak'}
                      </span>
                    </td>
                    <td>${item.probability}%</td>
                    <td>
                      <button class="btn btn-sm btn-outline-primary view-detail-btn" data-index="${index}">
                        <i class="fas fa-eye me-1"></i>Detail
                      </button>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        `}
      </section>
      
      <!-- Modal for Detail View -->
      <div class="modal fade" id="detailModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Detail Analisis</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="modal-body-content">
              <!-- Content will be loaded here -->
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  async afterRender() {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user) return;

    // Initialize modal
    this.modal = new bootstrap.Modal(document.getElementById('detailModal'));
    
    // Add event listeners to view detail buttons
    document.querySelectorAll('.view-detail-btn').forEach(button => {
      const handler = () => {
        const index = button.dataset.index;
        this._showDetail(index);
      };
      button.addEventListener('click', handler);
      this.viewDetailHandlers.push({ button, handler });
    });

    // Focus main content for accessibility
    const mainContent = document.querySelector('main');
    if (mainContent) {
      mainContent.setAttribute('tabindex', '-1');
      mainContent.focus();
    }
  }

  async _showDetail(index) {
    const analysis = this.historyData[index];
    if (!analysis) return;

    document.getElementById('modal-body-content').innerHTML = `
      <div class="row">
        <div class="col-md-6">
          <img src="${analysis.image}" alt="Analisis kulit" class="img-fluid rounded mb-3">
          <div class="d-flex justify-content-between">
            <div>
              <h6>Tanggal Analisis:</h6>
              <p>${analysis.date}</p>
            </div>
            <div>
              <h6>Hasil:</h6>
              <span class="badge ${analysis.isMalignant ? 'bg-danger' : 'bg-success'}">
                ${analysis.isMalignant ? 'Potensi Kanker' : 'Jinak'}
              </span>
            </div>
            <div>
              <h6>Probabilitas:</h6>
              <p>${analysis.probability}%</p>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <h5>Karakteristik Lesi:</h5>
          <ul class="list-group mb-3">
            <li class="list-group-item d-flex justify-content-between align-items-center">
              Asimetri
              <span class="badge bg-primary rounded-pill">${analysis.features.asymmetry}</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              Batas
              <span class="badge bg-primary rounded-pill">${analysis.features.border}</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              Warna
              <span class="badge bg-primary rounded-pill">${analysis.features.color}</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              Diameter
              <span class="badge bg-primary rounded-pill">${analysis.features.diameter}</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              Evolusi
              <span class="badge bg-primary rounded-pill">${analysis.features.evolution}</span>
            </li>
          </ul>
          
          <h5>Rekomendasi:</h5>
          <div class="alert ${analysis.isMalignant ? 'alert-danger' : 'alert-success'}">
            <i class="fas ${analysis.isMalignant ? 'fa-exclamation-triangle' : 'fa-check-circle'} me-2"></i>
            ${analysis.recommendation}
          </div>
        </div>
      </div>
    `;

    this.modal.show();
  }

  cleanup() {
    // Clean up modal
    if (this.modal) {
      this.modal.dispose();
    }
    
    // Clean up event listeners
    this.viewDetailHandlers.forEach(({ button, handler }) => {
      button.removeEventListener('click', handler);
    });
    this.viewDetailHandlers = [];
  }
}

export default HistoryPage;