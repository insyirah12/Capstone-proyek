import routes from '../routes/routes';
import { getActiveRoute } from '../routes/url-parser';
import { getActivePathname } from '../routes/url-parser';

export default class App {
  constructor() {
    this.currentPage = null;
    this.mainContent = document.getElementById('main-content');
    this.navLinks = document.querySelectorAll('.nav-link');
  }

  async init() {
    // Initialize the app
    this.setupNavigation();
    this.setupNavbar();
    await this.renderPage();
    this.initAOS();
    this.setupAuthState();
  }

async renderPage() {
  const path = getActivePathname();
  const route = getActiveRoute();
  
  const PageClass = routes[route];
  
  if (!PageClass) {
    console.error(`No route found for: ${route}`);
    return;
  }

  // Check authentication for protected routes
  const user = JSON.parse(localStorage.getItem('user'));
  if (PageClass.prototype.isProtected && !user) {
    window.location.hash = '#/login';
    return;
  }

  // Clean up previous page if exists
  if (this.currentPage?.cleanup) {
    await this.currentPage.cleanup();
  }

  // Create new page instance
  this.currentPage = new PageClass();

    try {
      // Render the new page
      this.mainContent.innerHTML = await this.currentPage.render();
      
      // Initialize page-specific functionality
      if (this.currentPage.afterRender) {
        await this.currentPage.afterRender();
      }
      
      // Update active nav link
      this.updateActiveNavLink(path);
      
    } catch (error) {
      console.error('Error rendering page:', error);
      this.mainContent.innerHTML = `
        <div class="alert alert-danger">
          <h4>Error loading page</h4>
          <p>${error.message}</p>
        </div>
      `;
    }
  }

  setupNavigation() {
    // Handle hash changes
    window.addEventListener('hashchange', () => {
      this.renderPage();
    });
  }

  setupNavbar() {
    // Handle navbar toggler for mobile
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');
    
    if (navbarToggler && navbarCollapse) {
      navbarToggler.addEventListener('click', () => {
        navbarCollapse.classList.toggle('show');
      });
    }
  }

  updateActiveNavLink(currentPath) {
    this.navLinks.forEach(link => {
      const linkPath = link.getAttribute('href').replace('#', '');
      const selector = `[href="#${linkPath}"]`; // Valid selector
      
      if (currentPath === linkPath || 
          (currentPath.startsWith(linkPath) && linkPath !== '/')) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  }

  initAOS() {
    if (typeof AOS !== 'undefined') {
      AOS.init({
        duration: 800,
        once: true
      });
    }
  }

  async cleanup() {
    if (this.currentPage?.cleanup) {
      await this.currentPage.cleanup();
    }
  }

  setupAuthState() {
    const authContainer = document.getElementById('authContainer');
    const loginBtnNav = document.getElementById('loginBtnNav');
    const userDropdown = document.getElementById('userDropdown');
    const userAvatar = document.getElementById('userAvatar');
    const logoutBtn = document.getElementById('logoutBtn');
    const userNameDisplay = document.createElement('span'); // Create element for username

    if (!authContainer) return;

    const user = JSON.parse(localStorage.getItem('user'));
    
    if (user) {
      // User is logged in
      loginBtnNav.classList.add('d-none');
      userDropdown.classList.remove('d-none');
      userAvatar.src = user.avatar;
      
      // Add username next to avatar
      userNameDisplay.className = 'ms-2 d-none d-md-inline';
      userNameDisplay.textContent = user.name;
      userDropdown.querySelector('a').appendChild(userNameDisplay);
    } else {
      // User is not logged in
      loginBtnNav.classList.remove('d-none');
      userDropdown.classList.add('d-none');
    }

    // Handle logout
    logoutBtn?.addEventListener('click', (e) => {
      e.preventDefault();
      localStorage.removeItem('user');
      window.location.hash = '#/login';
      window.location.reload();
    });
  }
}