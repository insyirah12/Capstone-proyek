export const loading = {
    show: (message = 'Memuat...') => {
      let overlay = document.getElementById('loading-overlay');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'loading-overlay';
        overlay.className = 'loading-overlay';
        overlay.innerHTML = `
          <div class="loading-content">
            <div class="loading-spinner"></div>
            <div class="loading-text">${message}</div>
          </div>
        `;
        document.body.appendChild(overlay);
      }
      overlay.classList.add('active');
      const textElement = overlay.querySelector('.loading-text');
      if (textElement) {
        textElement.textContent = message;
      }
    },
    
    hide: () => {
      const overlay = document.getElementById('loading-overlay');
      if (overlay) {
        overlay.classList.remove('active');
        // Optional: Remove after animation
        setTimeout(() => {
          if (overlay.classList.contains('active') === false) {
            overlay.remove();
          }
        }, 300);
      }
    }
  };