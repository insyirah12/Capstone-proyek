import App from './pages/app';
import '../style/style.css';

document.addEventListener('DOMContentLoaded', async () => {
  const app = new App();
  await app.init();
  
  // Cleanup on page unload if needed
  window.addEventListener('beforeunload', () => app.cleanup());
});