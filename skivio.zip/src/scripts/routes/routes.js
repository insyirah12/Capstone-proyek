import HomePage from '../pages/home-page/home-page';
import DetectionPage from '../pages/detection-page/detection-page';
import AboutPage from '../pages/about-page/about-page';
import LoginPage from '../pages/login/login-page';
import HistoryPage from '../pages/history-page/history-page';

const routes = {
  '/': HomePage,
  '/about': AboutPage,
  '/detection': DetectionPage,
  '/login': LoginPage,
  '/history': HistoryPage
};

export default routes;

