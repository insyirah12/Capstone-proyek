# Klasifikasi Kanker Kulit menggunakan MobileNetV2

## Deskripsi
Project ini bertujuan untuk mengklasifikasikan jenis-jenis kanker kulit berdasarkan gambar menggunakan deep learning dengan arsitektur MobileNetV2. Dataset yang digunakan adalah kumpulan gambar penyakit kulit dari Kaggle (https://www.kaggle.com/datasets/riyaelizashaju/skin-disease-classification-image-dataset).

Model ini dapat membantu mendeteksi beberapa jenis penyakit kulit, termasuk melanoma, aktinik keratosis, dan lainnya, berdasarkan input gambar kulit.

## Struktur Dataset
- Dataset awal dibagi ke dalam folder `train` dan `val` dengan beberapa kelas penyakit kulit.
- Dataset kemudian dilakukan augmentasi untuk menyeimbangkan jumlah gambar per kelas.
- Data dipisah menjadi data training dan testing menggunakan stratified split.

## Teknologi & Library
- Python 3.x
- TensorFlow & Keras (MobileNetV2 pretrained)
- NumPy, Pandas
- Pillow (PIL)
- Matplotlib, Seaborn
- scikit-learn (untuk train_test_split)

## Cara Menggunakan Model

1. **Persiapan environment**  
   Install dependencies menggunakan:

   ```bash
   pip install -r requirements.txt
2. **Load model**
  File model telah disimpan dalam model_klasifikasi.h5. Kamu dapat load model dengan:
    from tensorflow.keras.models import load_model
    model = load_model('model_klasifikasi.h5')
3. **Prediksi gambar**
  Siapkan gambar berukuran 224x224 piksel dan lakukan preprocessing dengan fungsi preprocess_input dari MobileNetV2 sebelum prediksi.
  Contoh:
    from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
    from PIL import Image
    import numpy as np

    img = Image.open('path_to_image.jpg').resize((224, 224))
    img_array = np.array(img)
    img_preprocessed = preprocess_input(img_array)
    img_preprocessed = np.expand_dims(img_preprocessed, axis=0)

    prediction = model.predict(img_preprocessed)
    class_index = np.argmax(prediction)
4. **Output**
   Output adalah probabilitas kelas penyakit kulit yang diprediksi.

**Catatan**
  - Model ini menggunakan transfer learning dengan MobileNetV2 yang sudah dilatih di ImageNet.
  - Dataset sudah melalui proses augmentasi untuk mengatasi ketidakseimbangan data.
  - Pastikan gambar input memiliki kualitas dan ukuran yang sesuai agar hasil prediksi akurat.
